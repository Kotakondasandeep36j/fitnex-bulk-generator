FITNEX PWA — PWABuilder Package

This package contains the FITNEX Bulk Generator prepared for PWABuilder.

Files:
- index.html       Main FITNEX app
- manifest.json    PWA web manifest
- sw.js            Offline service worker
- icons/           PWA launcher icons

Important:
PWABuilder analyzes a publicly reachable HTTPS URL. Upload this folder to a static web host, open the deployed HTTPS URL in PWABuilder, and choose Android to generate an Android package.

Recommended PWABuilder Android settings:
- App name: FITNEX Bulk Generator
- Launcher name: FITNEX
- Display: Standalone
- Package ID: com.fitnex.bulk.generator
- Theme/background: already configured in manifest

The app itself is self-contained and its FITNEX template is embedded in index.html, so no external template file is required.
